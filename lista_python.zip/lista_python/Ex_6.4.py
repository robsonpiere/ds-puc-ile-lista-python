fruta = "banana"
letra = "a"

total = fruta.count("a")

print("Existe(m) "  + str(total) +  " ocorrência(s) de '" + letra + "' em "  + fruta)