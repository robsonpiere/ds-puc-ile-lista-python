# Lista de Exercícios python

Lista de exerícios python pós graduação em ciência de dados e big data puc minas


1. Necessário python 3.x
2. Pode ser executado via terminal ou IDE


### Como rodar os scripts via terminal / cmd:
```
>>> python Ex_x.x.py
```