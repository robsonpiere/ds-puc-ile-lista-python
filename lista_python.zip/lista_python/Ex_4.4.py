print("Qual o propósito da palavra-chave def em Python?")
print("a) É uma gíria que significa 'o seguinte código é muito legal'")
print("b) Indica o começo de uma função")
print("c) Indica que a sequência de código identada seguinte deve ser armazenada para posterior utilização")
print("d) b e c são ambas verdadeiras")
print("e) n.d.a")
resposta = input("Digite a letra correspondente:")
if resposta == "d":
    print("Certa resposta!")
else:
    print("Que pena, você errou....")