fruta = "jabuticaba"
print(fruta[:])

"""
Resposta: fruta[:] representa a string completa
"""