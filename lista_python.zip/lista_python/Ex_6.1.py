palavra = input("Digite uma palavra qualquer: ")
indice = len(palavra) - 1
while indice >= 0:
   print(palavra[indice])
   indice = indice - 1