print("Digite seu nome: ", end=' ')
nome = input()
print("Olá " + nome + " !")
