def fred():
    print ("Zap")

def jane():
    print("ABC")

jane()
fred()
jane()

"""
Resposta: reposta D, o código acima imprime ABC Zap Abc
"""