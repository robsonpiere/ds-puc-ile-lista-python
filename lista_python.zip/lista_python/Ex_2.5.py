print("Informe a temperatura em Celsius:",end=' ')
celsius = float(input())
fahrenheit = (celsius * 1.8 + 32)
print("A temperatura equivalente em Fahrenheit é :" + str(fahrenheit))