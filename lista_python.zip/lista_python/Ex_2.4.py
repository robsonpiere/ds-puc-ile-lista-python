largura = 17
altura = 12.0

def imprimir_expressao(expressao):
    print("O valor da expressão é: " + str(expressao))
    tipo = str(type(expressao))
    print("O tipo do valor da expressão é: " + tipo,end='\n\n')

expressao1 = largura/2
expressao2 =largura/2.0
expressao3 = altura/3
expressao4 =  + 2 *5

imprimir_expressao(expressao1)
imprimir_expressao(expressao2)
imprimir_expressao(expressao3)
imprimir_expressao(expressao4)


